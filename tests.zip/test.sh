#!/usr/bin/env bash
# V5 verifier shell wrapper.
# This script writes /logs/verifier/reward.txt.
# Pattern: hardcode path, literal echo 0/1.
set -u

REWARD_FILE="/logs/verifier/reward.txt"
mkdir -p /logs/verifier

# Initial state: always 0 (grader can read at any point)
echo 0 > "$REWARD_FILE"

# Run python verifier; capture exit code
/usr/bin/python3 -I -S /tests/test_outputs.py
PY_RC=$?

# Final write: 1 iff python exited 0, else 0
if [ "$PY_RC" -eq 0 ]; then
    echo 1 > "$REWARD_FILE"
    exit 0
else
    echo 0 > "$REWARD_FILE"
    exit 1
fi
