/*
 * compliance-helper.c
 *
 * SUID root helper for the staging cluster's compliance pipeline.
 * Backs the compliance-sealer service by serving seal bytes over
 * a Unix domain socket.
 *
 * Protocol: one connection per request. The client sends:
 *   "read <request-id>\n"
 * The helper looks up the request file under /tmp/compliance/,
 * returns its contents, and closes the connection.
 *
 * The TOCTOU window is between lstat() (advisory ownership check)
 * and open()+read() (the actual file read). The owner check
 * requires the file be analyst-owned, so a player-owned request
 * file is rejected up front.
 *
 * Build:
 *   gcc -O2 -o compliance-helper compliance-helper.c
 *   chown root:root compliance-helper
 *   chmod 4755 compliance-helper
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <time.h>
#include <dirent.h>
#include <signal.h>

#define REQ_DIR "/tmp/compliance"
#define SEAL_PATH "/var/lib/compliance/audit_seal"
#define SOC_PATH "/var/run/compliance/helper.sock"
#define MAX_READ 4096
#define BACKLOG 8
#define ANALYST_UID 994

static int listen_fd = -1;

static void die(const char *msg) {
    fprintf(stderr, "compliance-helper: %s: %s\n", msg, strerror(errno));
    exit(1);
}

static int rand_sleep_ms(int lo, int hi) {
    int span = hi - lo;
    if (span <= 0) return lo;
    int ms = lo + (rand() % span);
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
    return ms;
}

/*
 * try_read_request: TOCTOU-vulnerable file read.
 *
 *   1. lstat() the path. Accept only regular files or symlinks
 *      owned by uid 994 (analyst). A symlink is the goal of the
 *      race.
 *   2. access(F_OK) — the race window opens.
 *   3. Sleep 15-60ms (wider window = more chances for the
 *      swapper to land its symlink).
 *   4. open() the path (follows symlinks because the binary
 *      has effective root privileges via SUID).
 *   5. read() and return the number of bytes read.
 */
static int try_read_request(const char *path, char *outbuf, int outsz) {
    struct stat lst;
    if (lstat(path, &lst) != 0) {
        return -1;
    }
    if (!S_ISREG(lst.st_mode) && !S_ISLNK(lst.st_mode)) {
        return -1;
    }
    if (lst.st_uid != ANALYST_UID) {
        return -1;
    }

    if (access(path, F_OK) != 0) {
        return -1;
    }

    rand_sleep_ms(15, 60);

    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        return -1;
    }

    ssize_t n = read(fd, outbuf, outsz - 1);
    close(fd);
    if (n <= 0) {
        return -1;
    }
    outbuf[n] = '\0';
    return (int)n;
}

/*
 * Handle a single client connection. The protocol is line-based:
 * the client sends one line with the command, we respond and
 * close.
 */
static void handle_client(int cfd) {
    char cmd[256] = {0};
    ssize_t n = read(cfd, cmd, sizeof(cmd) - 1);
    if (n <= 0) {
        close(cfd);
        return;
    }
    /* strip trailing whitespace/newline */
    while (n > 0 && (cmd[n-1] == '\n' || cmd[n-1] == '\r' || cmd[n-1] == ' ')) {
        cmd[--n] = '\0';
    }

    if (strncmp(cmd, "read ", 5) == 0) {
        const char *reqid = cmd + 5;
        /* Reject path traversal characters. */
        if (strchr(reqid, '/') || strchr(reqid, '.') || strchr(reqid, '\\')) {
            const char *msg = "ERR invalid request id\n";
            write(cfd, msg, strlen(msg));
            close(cfd);
            return;
        }
        char path[512];
        snprintf(path, sizeof(path), "%s/req.%s", REQ_DIR, reqid);

        char buf[MAX_READ];
        int got = try_read_request(path, buf, sizeof(buf));
        if (got < 0) {
            /* Fallback: scan the request dir for the latest file. */
            DIR *d = opendir(REQ_DIR);
            if (d) {
                struct dirent *de;
                char latest[512] = {0};
                time_t latest_mtime = 0;
                while ((de = readdir(d)) != NULL) {
                    if (strncmp(de->d_name, "req.", 4) != 0) continue;
                    char p[512];
                    snprintf(p, sizeof(p), "%s/%s", REQ_DIR, de->d_name);
                    struct stat st;
                    if (lstat(p, &st) == 0
                        && (S_ISREG(st.st_mode) || S_ISLNK(st.st_mode))
                        && st.st_uid == ANALYST_UID
                        && st.st_mtime > latest_mtime) {
                        latest_mtime = st.st_mtime;
                        strncpy(latest, p, sizeof(latest) - 1);
                    }
                }
                closedir(d);
                if (latest[0]) {
                    got = try_read_request(latest, buf, sizeof(buf));
                }
            }
        }
        if (got > 0) {
            write(cfd, buf, got);
        } else {
            const char *msg = "ERR no request found\n";
            write(cfd, msg, strlen(msg));
        }
    } else if (strcmp(cmd, "diag") == 0) {
        struct stat st;
        if (stat(SEAL_PATH, &st) != 0) {
            const char *msg = "ERR seal not installed\n";
            write(cfd, msg, strlen(msg));
        } else {
            char resp[256];
            int r = snprintf(resp, sizeof(resp),
                "OK seal_uid=%u seal_gid=%u seal_size=%lld seal_mode=%04o\n",
                st.st_uid, st.st_gid, (long long)st.st_size,
                st.st_mode & 07777);
            write(cfd, resp, r);
        }
    } else {
        const char *msg = "ERR unknown command\n";
        write(cfd, msg, strlen(msg));
    }
    close(cfd);
}

static void on_signal(int s) {
    (void)s;
    if (listen_fd >= 0) {
        close(listen_fd);
        unlink(SOC_PATH);
    }
    _exit(0);
}

int main(int argc, char **argv) {
    (void)argc;
    (void)argv;

    setpgid(0, 0);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGPIPE, SIG_IGN);

    unlink(SOC_PATH);

    listen_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (listen_fd < 0) die("socket");

    struct sockaddr_un addr = {0};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, SOC_PATH, sizeof(addr.sun_path) - 1);

    if (bind(listen_fd, (struct sockaddr *)&addr, sizeof(addr)) != 0) {
        die("bind");
    }
    if (listen(listen_fd, BACKLOG) != 0) {
        die("listen");
    }
    /* Restrict socket to the analyst group. */
    chown(SOC_PATH, 0, ANALYST_UID);
    chmod(SOC_PATH, 0660);

    fprintf(stderr, "compliance-helper: listening on %s\n", SOC_PATH);

    while (1) {
        int cfd = accept(listen_fd, NULL, NULL);
        if (cfd < 0) {
            if (errno == EINTR) continue;
            die("accept");
        }
        handle_client(cfd);
    }
    return 0;
}
