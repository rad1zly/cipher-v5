"""
Internal API gateway for the staging cluster.

Exposes a small set of endpoints used by the metrics pipeline:
  GET  /health          -> liveness probe
  GET  /api/describe    -> metric metadata lookup
  GET  /api/legacy/<id> -> legacy metric fetch from on-disk cache
  POST /api/render      -> render a metric label template

The /api/render endpoint composes labels by feeding the request
template through a small templating pass that supports a couple
of placeholder syntaxes. The implementation is a thin wrapper
around Jinja2 for the variable substitution step.
"""

import os
import re
import json
import socket
from datetime import datetime, timezone
from flask import Flask, request, jsonify, Response
from jinja2 import Environment

app = Flask(__name__)

CACHE_DIR = "/opt/gateway/cache"
DECOY_DIR = "/opt/gateway/decoys"
LOG_PATH = "/var/log/gateway/access.log"


def _log(line):
    with open(LOG_PATH, "a") as f:
        f.write(line + "\n")


# The render pass uses Jinja2 with no autoescape and a small
# fixed context. The pipeline relies on the standard {{var}} and
# {% ... %} syntax for label composition.
_jinja = Environment(autoescape=False, keep_trailing_newline=True)


def _render_label(tpl: str) -> str:
    ctx = {
        "host": socket.gethostname(),
        "now": datetime.now(timezone.utc).isoformat(),
        "env": "staging",
        "cluster": "stg-7",
    }
    try:
        tmpl = _jinja.from_string(tpl)
        return tmpl.render(**ctx)
    except Exception as exc:
        return f"<render-error: {exc}>"


@app.route("/health")
def health():
    return jsonify({"status": "ok", "ts": datetime.now(timezone.utc).isoformat()})


@app.route("/api/describe")
def describe():
    metric = request.args.get("metric", "")
    if not metric or not re.match(r"^[a-zA-Z0-9_.-]{1,64}$", metric):
        return jsonify({"error": "invalid metric name"}), 400
    return jsonify({
        "metric": metric,
        "unit": "count",
        "interval": 15,
        "description": f"Per-host counter for {metric}",
    })


@app.route("/api/legacy/<mid>")
def legacy(mid):
    if not re.match(r"^[a-f0-9]{8,32}$", mid):
        return jsonify({"error": "invalid id"}), 400
    path = os.path.join(CACHE_DIR, f"{mid}.json")
    if not os.path.exists(path):
        return jsonify({"error": "not found"}), 404
    with open(path) as f:
        return Response(f.read(), mimetype="application/json")


@app.route("/api/render", methods=["GET", "POST"])
def render():
    if request.method == "POST":
        tpl = request.form.get("tpl", "")
    else:
        tpl = request.args.get("tpl", "")
    if not tpl:
        return jsonify({"error": "missing tpl"}), 400
    if len(tpl) > 1024:
        return jsonify({"error": "tpl too long"}), 400
    rendered = _render_label(tpl)
    _log(f"render tpl={tpl!r} -> {rendered!r}")
    return jsonify({"rendered": rendered})


if __name__ == "__main__":
    os.makedirs(CACHE_DIR, exist_ok=True)
    os.makedirs(DECOY_DIR, exist_ok=True)
    # Bind to loopback only — iptables handles cross-user policy
    app.run(host="127.0.0.1", port=8080, debug=False, use_reloader=False)
