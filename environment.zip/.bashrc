# Analyst bash profile — keeps PATH sane, sets prompt.
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export PS1='analyst@stg-7:\w$ '
umask 022
