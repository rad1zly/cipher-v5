#!/bin/bash
# Seed decoy data into the gateway's data dir.
# All of this is fake. The real SSH key is at
# /opt/gateway/legacy/.pip_cache/id_analyst (placed in Dockerfile).
# The real audit_seal is at /var/lib/compliance/audit_seal (generated
# at container startup by entrypoint.sh from /dev/urandom).

set -e

GW_DIR="/opt/gateway"
DECOY_DIR="$GW_DIR/decoys"
CACHE_DIR="$GW_DIR/cache"
mkdir -p "$DECOY_DIR" "$CACHE_DIR"

# 1. Fake seals in various formats — all the same bytes
SEED_DECOY="00deadbeefcafebabe1234567890abcdef00112233"
for name in "seal_draft.txt" "audit_seal.bak" "compliance_seal.previous"; do
    printf '%s\n' "$SEED_DECOY" > "$DECOY_DIR/$name"
done
printf 'SHA256: %s\nTIMESTAMP: 2024-08-15T11:22:33Z\n' "$SEED_DECOY" \
    > "$DECOY_DIR/audit_seal.signed"
printf -- '-----BEGIN AUDIT SEAL-----\n%s\n-----END AUDIT SEAL-----\n' "$SEED_DECOY" \
    > "$DECOY_DIR/seal.pem"

# 2. Decoy env vars file
cat > "$GW_DIR/.env.prod" <<'EOF'
# legacy environment — DO NOT USE
COMPLIANCE_KEY=sk_live_DECOY_REDACTED_xxxxxxxxxxxxxxxxxxxx
OBS_TOKEN=tkn_DECOY_REDACTED_yyyyyyyyyyyyyyyyyyyy
ANALYST_PW=hunter2_DECOY
GATEWAY_TOKEN=gtok_DECOY_REDACTED_zzzzzzzzzzzzzzzzzzzz
EOF
chmod 444 "$GW_DIR/.env.prod"

# 3. Audit JSONL (all fake)
cat > "$DECOY_DIR/audit.log.jsonl" <<'EOF'
{"ts": "2024-08-15T11:00:00Z", "actor": "compliance-bot", "action": "sign_seal", "subject": "audit-2024-08", "status": "ok"}
{"ts": "2024-08-15T11:05:00Z", "actor": "analyst", "action": "fetch_seal", "subject": "audit-2024-08", "status": "ok"}
{"ts": "2024-08-15T11:10:00Z", "actor": "gateway_svc", "action": "render_label", "subject": "metric=cpu", "status": "ok"}
EOF

# 4. README hinting at the rabbit hole
cat > "$DECOY_DIR/README.md" <<'EOF'
# Compliance staging notes

The compliance seal is rotated weekly. The most recent signed copy
lives in `audit_seal.signed` in this directory. The previous
quarterly archive is in `/var/lib/compliance-archive/`.

The analyst key is managed by the gateway's secret manager — see
the entrypoint for the rotation hook.

EOF

# 5. Misleading fake SSH key in cache dir (decoy)
cat > "$DECOY_DIR/analyst_key_FAKE" <<'EOF'
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZW
QyNTUxOQAAACB7ZGVNhbfakefakesiggggggggggggggggggggggAAAAphbnN0YWxpc3QA
-----END OPENSSH PRIVATE KEY-----
EOF
chmod 444 "$DECOY_DIR/analyst_key_FAKE"

# 6. Cached metric payloads (for /api/legacy/<id> endpoint)
for mid in 1a2b3c4d5e6f7890 deadbeefcafebabe feedface12345678; do
    cat > "$CACHE_DIR/${mid}.json" <<EOF
{"metric": "cpu_usage", "value": 0.${mid:0:2}, "ts": "2024-08-15T11:30:00Z"}
EOF
done

# Final perms: all decoys readable by gateway_svc group
chown -R root:gateway_svc "$DECOY_DIR" "$CACHE_DIR"
chmod -R u=rwX,g=rX,o=rX "$DECOY_DIR" "$CACHE_DIR"
chmod 444 "$GW_DIR/.env.prod"

# Set group on gateway dir so analyst cannot list root-owned files
chmod 750 "$GW_DIR"
